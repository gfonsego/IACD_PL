1. Run task4.py

    `python task4.py customer-orders.csv > output.txt`

    This will save the output in a file called output.txt sorted by the total amount spent by each customer.