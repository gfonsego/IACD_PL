1. Run task2.py

    `python task2.py 1800.csv > output.txt`

    This will save the output in a file called output.txt