1. Run task1.py

    `python task1.py fakefriends.csv | sort -k1,1n > output.txt`

    This will save the output in a file called output.txt sorted by age.