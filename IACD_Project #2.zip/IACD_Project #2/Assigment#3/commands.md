# Task 1

1. Run pyspark script
`spark-submit task1.py`

# Task 2 and 3

1. Run pyspark script
`spark-submit task2-3.py`

# Task 4 and 5

1. Run pyspark script
`spark-submit task4-5.py`

# Task 6 and 7

1. Run pyspark script
`spark-submit task6-7.py`

   * Most Popular: Captain America = 1937
   * Least Popular: 
