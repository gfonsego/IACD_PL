1. Run task3.py

    `python task3.py Book > output.txt`

    This will save the output in a file called output.txt sorted by word frequency.